/**
 * This is interfaces namely HasRule.
 * Interfaces HasRule include gameRule() method for return rule of game.
 *
 * Autor : Anchana  Camchern
 * Student ID : 633040185-7
 * Section 2
 * Date 4th March 2021
 */

package camchern.anchana.lab6;

public interface HasRule {
    public String gameRule();
}
