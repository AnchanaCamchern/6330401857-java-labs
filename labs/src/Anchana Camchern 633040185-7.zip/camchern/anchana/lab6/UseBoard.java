/**
 * This is interfaces namely UseBoard.
 * Interfaces UseBoard include setUpBoard() method.
 *
 * Autor : Anchana  Camchern
 * Student ID : 633040185-7
 * Section 2
 * Date 4th March 2021
 */

package camchern.anchana.lab6;

public interface UseBoard {
    public void setUpBoard();
}
