/**
 * This is interfaces namely UseDice.
 * Interfaces UseBoard include rollDice() method.
 *
 * Autor : Anchana  Camchern
 * Student ID : 633040185-7
 * Section 2
 * Date 4th March 2021
 */

package camchern.anchana.lab6;

public interface UseDice {
    public int rollDice();
}
