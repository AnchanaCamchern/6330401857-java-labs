package camchern.anchana.Test01.GUI;

import javax.swing.*;

public class HelloWordGUI1 {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null,"Hello Students!");
    }
}
