package anchana;

public class PhoneNum {
    public static void main(String[] args) {
        int [] list ={0, 6, 5, 8, 5, 0, 3, 2, 9 ,1};
        for (int i = 0; i < list.length; i++) {
            System.out.println(list[i] + "");
        }
    }
}
