package camchern.anchana.examV1;

class Adder {
     private int number1;
     private int number2;
     public  Adder(int number1,int number2) {
         this.number1 = number1;
         this.number2 = number2;
     }
     public void add() {
         System.out.println(number1 + " + " + number2 + " = " + (number1 + number2));
     }
}



/**
 try {
 int number1 = Integer.parseInt(args[0]);
 int number2 = Integer.parseInt(args[1]);
 int answer = number1 + number2;
 System.out.println(number1 + " + " + number2 + " = " +
 answer);
 } catch (ArrayIndexOutOfBoundsException ex) {
 System.err.println("Please provide two a argument");
 } catch (NumberFormatException ex) {
 System.err.println("Please provide two integers");
 }*/