package camchern.anchana.examV1;

public class TestExamV1 {
    public static void main(String[] args) {
        Adder adder = new Adder(2,3);
        adder.add();
    }
}
